import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
const stage=document.querySelector('#material-stage');
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;stage.append(renderer.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color('#EDF2F7');
const pmrem=new THREE.PMREMGenerator(renderer),room=new RoomEnvironment();scene.environment=pmrem.fromScene(room,.04).texture;scene.environmentIntensity=.8;room.dispose();pmrem.dispose();scene.add(new THREE.HemisphereLight(0xf5f8fc,0x506276,2));
const key=new THREE.DirectionalLight(0xf5f8fc,3);key.position.set(7,10,6);scene.add(key);const fill=new THREE.DirectionalLight(0xb9e7ff,1);fill.position.set(-6,4,-5);scene.add(fill);
// Deterministic neutral micrograin: no color information or baked illumination.
const pixels=new Uint8Array(128*128*4);let seed=1397;for(let i=0;i<128*128;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const n=((seed>>>24)/255-.5)*12;pixels[i*4]=128+n;pixels[i*4+1]=128-n;pixels[i*4+2]=255;pixels[i*4+3]=255;}
const grain=new THREE.DataTexture(pixels,128,128);grain.wrapS=grain.wrapT=THREE.RepeatWrapping;grain.repeat.set(12,12);grain.needsUpdate=true;
const shared=new THREE.MeshStandardMaterial({color:'#11151B',metalness:.35,roughness:.5,normalMap:grain,normalScale:new THREE.Vector2(.12,.12)});
const currentBoom=new THREE.MeshStandardMaterial({color:'#202A36',metalness:.35,roughness:.5});const currentSteps=new THREE.MeshStandardMaterial({color:'#26303C',metalness:.6,roughness:.42});
[shared,currentBoom,currentSteps].forEach((material,index)=>{const object=new THREE.Group(),cube=new THREE.Mesh(new THREE.BoxGeometry(.7,1.15,.6),material),ball=new THREE.Mesh(new THREE.SphereGeometry(.32,48,32),material);cube.position.y=-.17;cube.rotation.set(.08,.27,0);ball.position.y=.68;object.position.x=(index-1)*1.2;object.add(cube,ball);scene.add(object);});
const camera=new THREE.PerspectiveCamera(32,1,.01,40);camera.position.set(0,1.4,7);camera.lookAt(0,.2,0);
function render(){renderer.render(scene,camera);}
function resize(){const w=stage.clientWidth,h=stage.clientHeight;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();render();}new ResizeObserver(resize).observe(stage);resize();
document.querySelectorAll('[data-surface]').forEach(b=>b.addEventListener('click',()=>{scene.background.set(b.dataset.surface==='carbon'?'#11151B':'#EDF2F7');document.querySelectorAll('[data-surface]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));render();}));
