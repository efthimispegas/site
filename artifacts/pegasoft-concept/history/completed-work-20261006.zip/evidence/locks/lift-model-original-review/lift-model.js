import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const $ = s => document.querySelector(s);
const stage = $('#stage'), status = $('#mesh-status'), message = $('#load-message');
const controlsUI = [...document.querySelectorAll('.viewer button')];
controlsUI.forEach(b => b.disabled = true);
const references = {right:'../generation/L01/L01-side.png',front:'../generation/lift-family/lift-front.png',rear:'../generation/lift-family/lift-rear.png',left:'../generation/lift-family/lift-left.png'};
$('#reference-view').addEventListener('change',e=>{const v=e.target.value;$('#reference-image').src=references[v];$('#reference-image').alt=`Approved ${v} static lift`;$('#reference-brand').hidden=v!=='right';});
let renderer, controls, camera, scene, root, floor, fitDistance, targetHeight;
const meshes = [], surfaceColors = {carbon:'#11151B',porcelain:'#EDF2F7'};
let ready = false;

function fail(error){console.error('Lift draft viewer:',error);status.textContent='3D preview unavailable';message.hidden=true;$('#fallback').hidden=false;stage.dataset.loaded='error';}
function selectGroup(selector,chosen){document.querySelectorAll(selector).forEach(b=>b.setAttribute('aria-pressed',String(b===chosen)));}
function setView(view){
  controls.autoRotate=false;$('#auto').setAttribute('aria-pressed','false');
  controls.enableDamping=false;controls.update();controls.enableDamping=true;
  const offsets={quarter:[1.15,.4,1.2],right:[0,.17,1.7],front:[1.7,.17,0],left:[0,.17,-1.7],rear:[-1.7,.17,0]};
  const o=offsets[view];controls.target.set(0,targetHeight,0);camera.position.set(...o.map((v,i)=>v*fitDistance/1.7+(i===1?targetHeight:0)));controls.update();
  selectGroup('[data-view]',document.querySelector(`[data-view="${view}"]`));
}
function setSurface(surface){scene.background=new THREE.Color(surfaceColors[surface]);floor.material.color.set(surfaceColors[surface]);selectGroup('[data-surface]',document.querySelector(`[data-surface="${surface}"]`));stage.dataset.surface=surface;}
function reset(){controls.autoRotate=false;$('#auto').setAttribute('aria-pressed','false');meshes.forEach(m=>{for(const mat of Array.isArray(m.material)?m.material:[m.material])mat.wireframe=false;});$('#wireframe').setAttribute('aria-pressed','false');setView('quarter');}
function zoom(factor){camera.position.sub(controls.target).multiplyScalar(factor).add(controls.target);controls.update();}
function resize(){if(!renderer)return;const w=stage.clientWidth,h=stage.clientHeight;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();}

async function init(){
  renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;stage.appendChild(renderer.domElement);
  renderer.domElement.setAttribute('aria-hidden','true');
  scene=new THREE.Scene();scene.background=new THREE.Color(surfaceColors.carbon);
  const pmrem=new THREE.PMREMGenerator(renderer), room=new RoomEnvironment();scene.environment=pmrem.fromScene(room,.04).texture;room.dispose();pmrem.dispose();scene.environmentIntensity=.8;
  scene.add(new THREE.HemisphereLight(0xf5f8fc,0x506276,2));
  const key=new THREE.DirectionalLight(0xf5f8fc,3);key.position.set(7,10,6);key.castShadow=true;key.shadow.mapSize.set(2048,2048);Object.assign(key.shadow.camera,{left:-8,right:8,top:8,bottom:-8,near:.1,far:35});key.shadow.normalBias=.025;key.shadow.bias=-.0001;scene.add(key);
  const fill=new THREE.DirectionalLight(0xb9e7ff,1);fill.position.set(-6,4,-5);scene.add(fill);
  camera=new THREE.PerspectiveCamera(36,1,.01,150);controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.08;controls.autoRotateSpeed=.65;controls.maxPolarAngle=Math.PI*.54;controls.minDistance=1;controls.maxDistance=35;
  floor=new THREE.Mesh(new THREE.PlaneGeometry(150,150),new THREE.MeshBasicMaterial({color:surfaceColors.carbon,toneMapped:false}));floor.rotation.x=-Math.PI/2;floor.position.y=-.02;scene.add(floor);
  const contactShadow=new THREE.Mesh(new THREE.PlaneGeometry(150,150),new THREE.ShadowMaterial({opacity:.28}));contactShadow.rotation.x=-Math.PI/2;contactShadow.position.y=-.015;contactShadow.receiveShadow=true;scene.add(contactShadow);
  new ResizeObserver(resize).observe(stage);resize();
  const response=await fetch('../generation/lift-family/model-draft/inspection.json');if(!response.ok)throw new Error('Draft inspection not available');const inspection=await response.json();
  message.textContent='Loading original mesh and textures…';
  const gltf=await new GLTFLoader().loadAsync('../generation/lift-family/model-draft/model.glb',p=>{if(p.total)message.textContent=`Loading original GLB · ${Math.round(p.loaded/p.total*100)}%`;});
  root=new THREE.Group();const object=gltf.scene;root.add(object);scene.add(root);
  const box=new THREE.Box3().setFromObject(object), size=box.getSize(new THREE.Vector3()), center=box.getCenter(new THREE.Vector3());
  const scale=6/Math.max(size.x,size.y,size.z);root.scale.setScalar(scale);object.position.sub(new THREE.Vector3(center.x,box.min.y,center.z));
  root.rotation.y=inspection.viewer_yaw_radians||0;
  targetHeight=size.y*scale*.48;const radius=size.length()*scale/2;fitDistance=radius/Math.sin(THREE.MathUtils.degToRad(camera.fov/2))*1.07;
  // Account for the narrower horizontal field of view on portrait review panels.
  fitDistance=Math.max(fitDistance,radius/(Math.sin(Math.atan(Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*camera.aspect)))*1.04);
  object.traverse(o=>{if(o.isMesh){meshes.push(o);o.castShadow=true;o.receiveShadow=true;}});
  controls.minDistance=radius*.7;controls.maxDistance=fitDistance*3;setView('quarter');
  let triangles=0,vertices=0;meshes.forEach(m=>{vertices+=m.geometry.attributes.position.count;triangles+=(m.geometry.index?m.geometry.index.count:m.geometry.attributes.position.count)/3;});
  $('#model-stats').replaceChildren(...Object.entries({'Meshes':meshes.length,'Triangles':Math.round(triangles).toLocaleString(),'Vertices':vertices.toLocaleString(),'Original file':`${(inspection.file_bytes/1024/1024).toFixed(1)} MB`}).map(([label,value])=>{const el=document.createElement('div');el.className='stat';const strong=document.createElement('strong'),span=document.createElement('span');strong.textContent=value;span.textContent=label;el.append(strong,span);return el;}));
  $('#observations').textContent=inspection.structural_note||'Original unrigged draft. Mechanical part separation remains to be assessed.';
  status.textContent='Original GLB · Unrigged draft';message.hidden=true;ready=true;stage.dataset.loaded='true';stage.dataset.surface='carbon';stage.dataset.triangles=String(triangles);controls.addEventListener('change',updateReadout);updateReadout();controlsUI.forEach(b=>b.disabled=false);
  controls.addEventListener('start',()=>{selectGroup('[data-view]',null);});
  document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
  document.querySelectorAll('[data-surface]').forEach(b=>b.addEventListener('click',()=>setSurface(b.dataset.surface)));
  $('#wireframe').addEventListener('click',()=>{const value=$('#wireframe').getAttribute('aria-pressed')!=='true';meshes.forEach(m=>{for(const mat of Array.isArray(m.material)?m.material:[m.material])mat.wireframe=value;});$('#wireframe').setAttribute('aria-pressed',String(value));});
  $('#auto').addEventListener('click',()=>{controls.autoRotate=!controls.autoRotate;$('#auto').setAttribute('aria-pressed',String(controls.autoRotate));});
  $('#zoom-in').addEventListener('click',()=>zoom(.85));$('#zoom-out').addEventListener('click',()=>zoom(1.18));$('#reset').addEventListener('click',reset);
  stage.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','=','-','Home'].includes(e.key)){e.preventDefault();if(e.key==='Home')reset();else if(['+','=','-'].includes(e.key))zoom(e.key==='-'?1.12:.89);else{const s=new THREE.Spherical().setFromVector3(camera.position.clone().sub(controls.target));if(e.key==='ArrowLeft')s.theta-=.1;if(e.key==='ArrowRight')s.theta+=.1;if(e.key==='ArrowUp')s.phi=Math.max(.05,s.phi-.1);if(e.key==='ArrowDown')s.phi=Math.min(Math.PI*.54,s.phi+.1);camera.position.setFromSpherical(s).add(controls.target);selectGroup('[data-view]',null);controls.update();}}});
}
function updateReadout(){if(ready){$('#pose-readout').textContent=`Azimuth ${(THREE.MathUtils.radToDeg(controls.getAzimuthalAngle())).toFixed(1)}° · Elevation ${(90-THREE.MathUtils.radToDeg(controls.getPolarAngle())).toFixed(1)}°\nDistance ${camera.position.distanceTo(controls.target).toFixed(2)} viewer units`;}}
let previousFrame=0;
function frame(t){requestAnimationFrame(frame);const dt=Math.min((t-previousFrame)/1000,.05);previousFrame=t;if(!renderer||!controls||document.hidden)return;controls.update(dt);renderer.render(scene,camera);}
init().catch(fail);requestAnimationFrame(frame);
