[watch] working dir: /Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj
[watch] using local file…

# watch: video report

- **Source:** /Users/whiskey/Work/site/docs/references/reference_walkthrough.mov
- **Local media:** `/Users/whiskey/Work/site/docs/references/reference_walkthrough.mov`
- **Title:** reference_walkthrough.mov
- **Duration:** 06:44 (404.4s)
- **Resolution:** 3016x1532 (h264)
- **Detail:** transcript
- **Cue frames:** 18 at transcript-flagged timestamps (transcript-cue)
- **Frame size:** max 960px wide, max 1998px tall
- **Transcript:** fallback disabled; no captions available

## Frames

Frames live at: `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames`

**Read each frame path below with the Read tool to view the image.** Frames are in chronological order; `t=MM:SS` is the absolute timestamp in the source video.

- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0000.jpg` (t=01:52, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0001.jpg` (t=01:53, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0002.jpg` (t=01:56, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0003.jpg` (t=02:13, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0004.jpg` (t=02:25, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0005.jpg` (t=02:26, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0006.jpg` (t=02:41, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0007.jpg` (t=02:46, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0008.jpg` (t=02:52, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0009.jpg` (t=03:06, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0010.jpg` (t=03:13, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0011.jpg` (t=03:18, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0012.jpg` (t=03:38, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0013.jpg` (t=03:39, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0014.jpg` (t=03:51, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0015.jpg` (t=04:36, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0016.jpg` (t=04:36, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj/frames/cue_0017.jpg` (t=04:38, reason=transcript-cue)

## Transcript

_Fallback disabled; no captions available._
_Re-run with `--detail balanced` for visual evidence, or configure a transcription backend with setup.py._

---
_Work dir: `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-9eqsutlj` — delete when done._
