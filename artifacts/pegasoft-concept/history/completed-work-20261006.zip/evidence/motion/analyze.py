"""Local native-frame motion index; numeric screening, never visual acceptance."""
from pathlib import Path
import csv, hashlib, json, subprocess, sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
SITE = ROOT.parents[1]
OUT = Path(__file__).resolve().parent
W, H = 192, 98
SOURCES = {
    'loader': 'loader_animation.mov',
    'hero': 'hero_walkthrough.mov',
    'main': 'reference_walkthrough.mov',
}
WINDOWS = [
    ('loader', 'Loader pulse and aperture', 0, 2.89, 'time'),
    ('hero-entry', 'Hero entry and hover', 0, 5, 'time/pointer'),
    ('hero-hover', 'Hero link and CTA pointer responses', 5, 9.5, 'pointer/time'),
    ('hero-exit', 'Globe exit and atmospheric wipe', 9.5, 14.24, 'scroll'),
    ('lift', 'Container attachment and lift', 110, 131, 'scroll'),
    ('handoff', 'Camera pivot and truck handoff', 131, 147, 'scroll'),
    ('road', 'Side-to-overhead road transition', 159, 177, 'scroll'),
    ('deck', 'Reversible road-to-deck alignment', 185, 211, 'scroll'),
    ('pullback', 'Ship pullback and cloud occlusion', 211, 243, 'scroll'),
    ('jet', 'Jet crossing and coupled trust reveal', 243, 278, 'scroll'),
]


def run(args):
    return subprocess.check_output(args, text=True)


def inspect_source(key, filename):
    src = SITE / 'docs/references' / filename
    probe = json.loads(run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                           '-show_frames', '-show_entries',
                           'frame=best_effort_timestamp_time', '-of', 'json', str(src)]))
    times = [float(f['best_effort_timestamp_time']) for f in probe['frames']]
    p = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', str(src), '-an',
                          '-vf', f'scale={W}:{H}', '-fps_mode', 'passthrough',
                          '-pix_fmt', 'gray', '-f', 'rawvideo', '-'], stdout=subprocess.PIPE)
    rows, previous = [], None
    nbytes = W * H
    for i, t in enumerate(times):
        data = bytearray()
        while len(data) < nbytes:
            chunk = p.stdout.read(nbytes - len(data))
            if not chunk:
                break
            data.extend(chunk)
        if len(data) != nbytes:
            raise RuntimeError(f'{key}: short decode at frame {i}')
        a = np.frombuffer(data, dtype=np.uint8).reshape(H, W).astype(np.float32)
        # Ignore the sticky award badge/rightmost strip. Keep small spatial ROIs.
        d = np.zeros_like(a) if previous is None else np.abs(a - previous)
        scene = d[4:94, 3:179]
        center = d[24:75, 40:150]
        text = d[27:85, 40:94]
        rows.append([i, t, float(scene.mean()), float((scene >= 5).mean()),
                     float(center.mean()), float(text.mean()),
                     float(a[42:56, 88:104].mean())])
        previous = a
    if p.wait() != 0:
        raise RuntimeError(f'{key}: ffmpeg failed')
    path = OUT / f'{key}-signals.csv'
    with path.open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['frame', 'source_pts_s', 'scene_mad_0_255',
                         'changed_fraction_threshold_5', 'center_mad',
                         'text_roi_mad', 'center_luminance'])
        writer.writerows(rows)
    differences = np.diff(times)
    result = {
        'source': str(src.relative_to(SITE)), 'frames_decoded': len(rows),
        'first_pts_s': times[0], 'last_pts_s': times[-1],
        'median_frame_interval_s': float(np.median(differences)),
        'max_frame_interval_s': float(max(differences)),
        'low_change_frame_fraction': sum(r[2] < .5 for r in rows[1:]) / (len(rows)-1),
        'signals': path.name,
        'note': 'Low-change is a lossy spatial metric, not proof of identical frames or animation frame rate.',
    }
    print(key, result['frames_decoded'], 'native frames screened', flush=True)
    return rows, result


def make_clip(key, source, start, end):
    dest = OUT / 'clips' / f'{key}.mp4'
    dest.parent.mkdir(exist_ok=True)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(start),
                    '-i', str(SITE / 'docs/references' / SOURCES[source]),
                    '-t', str(end-start), '-an', '-vf', 'scale=960:488',
                    '-fps_mode', 'passthrough', '-c:v', 'libx264',
                    '-preset', 'veryfast', '-crf', '22', '-pix_fmt', 'yuv420p',
                    '-movflags', '+faststart', str(dest)], check=True)
    probe = json.loads(run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                           '-show_streams', '-show_frames', '-show_entries',
                           'stream=r_frame_rate,avg_frame_rate:frame=best_effort_timestamp_time',
                           '-of', 'json', str(dest)]))
    return {'path': 'clips/' + dest.name, 'sha256': hashlib.sha256(dest.read_bytes()).hexdigest(),
            'frames': len(probe['frames']), 'rate': probe['streams'][0]['r_frame_rate'],
            'presentation_times_s': [float(f['best_effort_timestamp_time']) for f in probe['frames']],
            'nominal_source_offset_s': start,
            'note': 'Review proxy at source cadence; source PTS CSV remains timing authority. No interpolation.'}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    all_rows, sources = {}, {}
    for key, filename in SOURCES.items():
        all_rows[key], sources[key] = inspect_source(key, filename)
    windows = []
    for key, title, start, end, driver in WINDOWS:
        source = 'loader' if key == 'loader' else 'hero' if key.startswith('hero-') else 'main'
        candidates = [r for r in all_rows[source] if start <= r[1] < end]
        # Three spatial-change maxima with separation: diagnostic candidate cues only.
        selected = []
        for row in sorted(candidates, key=lambda r: r[4], reverse=True):
            if all(abs(row[1] - old[1]) > .35 for old in selected):
                selected.append(row)
            if len(selected) == 3:
                break
        peak_rows = sorted(selected, key=lambda r: r[1])
        windows.append({'id': key, 'title': title, 'source': source,
                        'start_s': start, 'end_s': end, 'driver': driver,
                        'peak_candidates': [{'frame': r[0], 'source_pts_s': r[1],
                                             'center_mad': r[4]} for r in peak_rows],
                        'clip': make_clip(key, source, start, end)})
        print(key, 'proxy complete', flush=True)
    manifest = {'method': 'Native decoded frame/PTS screening + localized ROI signals + event windows + live DOM geometry',
                'engine': 'local', 'signal_resolution': [W, H],
                'uniform_watch_fps_used': False, 'interpolated_frames': False,
                'sources': sources, 'windows': windows,
                'limitations': ['ROI change locates candidate events, not semantic object trajectories.',
                                'Recorded scroll speed/pauses do not specify scroll distance or easing.',
                                'No fidelity acceptance from this reference-only analysis.',
                                'Proxy seeks are approximate; presented video PTS and source PTS are shown separately.']}
    (OUT / 'motion-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    for source in SOURCES:
        cues = sorted(set(round(p['source_pts_s'], 6) for w in windows if w['source'] == source for p in w['peak_candidates']))
        (OUT / f'{source}-cue-times.txt').write_text(','.join(map(str, cues))+'\n')
    print('Motion manifest written', flush=True)


if __name__ == '__main__':
    main()
