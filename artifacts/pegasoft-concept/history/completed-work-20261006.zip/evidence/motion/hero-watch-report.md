[watch] working dir: /Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-61x4lyr1
[watch] using local file…

# watch: video report

- **Source:** /Users/whiskey/Work/site/docs/references/hero_walkthrough.mov
- **Local media:** `/Users/whiskey/Work/site/docs/references/hero_walkthrough.mov`
- **Title:** hero_walkthrough.mov
- **Duration:** 00:14 (14.2s)
- **Resolution:** 3016x1532 (h264)
- **Detail:** transcript
- **Cue frames:** 6 at transcript-flagged timestamps (transcript-cue)
- **Frame size:** max 960px wide, max 1998px tall
- **Transcript:** fallback disabled; no captions available

## Frames

Frames live at: `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-61x4lyr1/frames`

**Read each frame path below with the Read tool to view the image.** Frames are in chronological order; `t=MM:SS` is the absolute timestamp in the source video.

- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-61x4lyr1/frames/cue_0000.jpg` (t=00:02, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-61x4lyr1/frames/cue_0001.jpg` (t=00:02, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-61x4lyr1/frames/cue_0002.jpg` (t=00:03, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-61x4lyr1/frames/cue_0003.jpg` (t=00:11, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-61x4lyr1/frames/cue_0004.jpg` (t=00:14, reason=transcript-cue)
- `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-61x4lyr1/frames/cue_0005.jpg` (t=00:14, reason=transcript-cue)

## Transcript

_Fallback disabled; no captions available._
_Re-run with `--detail balanced` for visual evidence, or configure a transcription backend with setup.py._

---
_Work dir: `/Users/whiskey/Work/site/artifacts/pegasoft-concept/evidence/motion/watch/watch-61x4lyr1` — delete when done._
