from pathlib import Path
import json,struct,collections
p=Path(__file__).resolve().parent/'model-carbon-unified.glb';b=p.read_bytes();
import hashlib
assert hashlib.sha256(b).hexdigest()=='d9fd9e83480be86d3b5ab7568e583f9a54341ad20769ea75a23a3fa5919c7067';n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);bb=b[28+n:]
def a(i):
 x=d['accessors'][i];v=d['bufferViews'][x['bufferView']];k={'SCALAR':1,'VEC2':2,'VEC3':3}[x['type']];f={5126:'f',5125:'I'}[x['componentType']];w=struct.calcsize(f)*k;return [struct.unpack_from('<'+f*k,bb,v.get('byteOffset',0)+x.get('byteOffset',0)+j*v.get('byteStride',w)) for j in range(x['count'])]
faces=[];keys={};verts=[]
for pi,q in enumerate(d['meshes'][d['nodes'][0]['mesh']]['primitives']):
 pos=a(q['attributes']['POSITION']);ids=[x[0] for x in a(q['indices'])] if 'indices' in q else list(range(len(pos)))
 for ti in range(0,len(ids),3):
  pts=[pos[i] for i in ids[ti:ti+3]];ws=[]
  for pt in pts:
   key=tuple(round(x*1e5) for x in pt)
   if key not in keys:keys[key]=len(keys);verts.append(pt)
   ws.append(keys[key])
  faces.append((pi,ti//3,ws))
parent=list(range(len(faces)))
def root(i):
 while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
 return i
def union(i,j):
 i=root(i);j=root(j)
 if i!=j:parent[j]=i
edges={}
for i,(_,_,ws) in enumerate(faces):
 for k in range(3):
  e=tuple(sorted((ws[k],ws[(k+1)%3])))
  if e in edges:union(i,edges[e])
  else:edges[e]=i
comps=collections.defaultdict(list)
for i in range(len(faces)):comps[root(i)].append(i)
report=[]
for fs in comps.values():
 pts=[verts[w] for i in fs for w in faces[i][2]];lo=[min(p[k] for p in pts) for k in range(3)];hi=[max(p[k] for p in pts) for k in range(3)];cent=[sum(p[k] for p in pts)/len(pts) for k in range(3)]
 if cent[0]<-.4 and cent[1]>-.15:
  report.append({'count':len(fs),'min':lo,'max':hi,'center':cent,'faces':[(faces[i][0],faces[i][1]) for i in fs]})
# Explicit ownership of the connected spreader frame and its four outboard
# hardware components. Do not widen the general chassis/spreader cut.
selected=[r for r in report if r['max'][0]>-.62 and r['max'][0]<-.59 and r['min'][0]<-.596 and r['min'][1]>.09 and r['max'][1]<.34]
assert sorted(r['count'] for r in selected)==[14,41,50,102,11529]
streams={str(d['accessors'][q['attributes']['POSITION']]['count']):[] for q in d['meshes'][d['nodes'][0]['mesh']]['primitives']}
for r in selected:
 for pi,ti in r['faces']:
  q=d['meshes'][d['nodes'][0]['mesh']]['primitives'][pi];streams[str(d['accessors'][q['attributes']['POSITION']]['count'])].append(ti)
for key,ids in streams.items():
 ids.sort();ranges=[]
 for i in ids:
  if ranges and i==ranges[-1][1]+1:ranges[-1][1]=i
  else:ranges.append([i,i])
 streams[key]=ranges
manifest={'date_local':'2026-10-05','approved_input_sha256':hashlib.sha256(b).hexdigest(),'method':'Position-welded edge connectivity at 1e-5 model units; explicit whole-component spreader ownership','component_count':len(selected),'component_triangles':sum(r['count'] for r in selected),'components':[{k:v for k,v in r.items() if k!='faces'} for r in selected],'spreader_triangle_ranges_by_position_count':streams,'limits':'Ownership only. No source triangle deletion, geometry rebuild, material change or source GLB write.'}
out=p.parent/'attachment-ownership.json';out.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'components':len(selected),'triangles':manifest['component_triangles'],'output':str(out)}))
