import fs from 'node:fs';
import crypto from 'node:crypto';
import sharp from 'sharp';
import * as THREE from 'three';
const dir=new URL('./',import.meta.url),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const input=fs.readFileSync(new URL('model-boom-amended.glb',dir));
if(hash(input)!=='868af5e8189daa1a0769e7a9874923e9db6abd95024f6687a67262ad2889089e')throw Error('Boom input changed');
const jl=input.readUInt32LE(12),start=28+jl,bl=input.readUInt32LE(20+jl),doc=JSON.parse(input.subarray(20,20+jl));
const oldBinary=input.subarray(start,start+bl),chunks=[oldBinary];let offset=bl;
function accessor(id){const a=doc.accessors[id],v=doc.bufferViews[a.bufferView],size={SCALAR:1,VEC2:2,VEC3:3}[a.type],type={5126:Float32Array,5125:Uint32Array}[a.componentType];return new type(input.buffer,input.byteOffset+start+(v.byteOffset||0)+(a.byteOffset||0),a.count*size);}
function bytes(data,target){const v=doc.bufferViews.length;doc.bufferViews.push({buffer:0,byteOffset:offset,byteLength:data.length,...(target?{target}:{})});chunks.push(data);offset+=data.length;const pad=(4-offset%4)%4;if(pad){chunks.push(Buffer.alloc(pad));offset+=pad;}return v;}
function append(array,type,target){const v=bytes(Buffer.from(array.buffer,array.byteOffset,array.byteLength),target),a={bufferView:v,componentType:array instanceof Float32Array?5126:5125,count:array.length/({SCALAR:1,VEC2:2,VEC3:3}[type]),type};if(type==='VEC3'){a.min=[Infinity,Infinity,Infinity];a.max=[-Infinity,-Infinity,-Infinity];array.forEach((n,i)=>{a.min[i%3]=Math.min(a.min[i%3],n);a.max[i%3]=Math.max(a.max[i%3],n);});}doc.accessors.push(a);return doc.accessors.length-1;}
// Same deterministic, neutral normal-map micrograin as the accepted material sample.
const pixels=Buffer.alloc(128*128*4);let seed=1397;for(let i=0;i<128*128;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const n=((seed>>>24)/255-.5)*12;pixels[i*4]=128+n;pixels[i*4+1]=128-n;pixels[i*4+2]=255;pixels[i*4+3]=255;}
const png=await sharp(pixels,{raw:{width:128,height:128,channels:4}}).png().toBuffer();fs.writeFileSync(new URL('carbon-grain-normal.png',dir),png);
const image=doc.images.length;doc.images.push({bufferView:bytes(png),mimeType:'image/png',name:'Approved carbon neutral micrograin'});const sampler=doc.samplers.length;doc.samplers.push({magFilter:9729,minFilter:9987,wrapS:10497,wrapT:10497});const texture=doc.textures.length;doc.textures.push({source:image,sampler});
const color=new THREE.Color('#11151B'),material=doc.materials.length;doc.materials.push({name:'Pegasoft carbon — approved shared satin',pbrMetallicRoughness:{baseColorFactor:[color.r,color.g,color.b,1],metallicFactor:.35,roughnessFactor:.5},normalTexture:{index:texture,scale:.12},emissiveFactor:[0,0,0],doubleSided:true,extras:{srgb:'#11151B',approval:'../material-surface-approval.json',grain_seed:1397,texture_cycles_per_viewer_unit:12/.7}});
const source=doc.meshes[doc.nodes[0].mesh].primitives[0],pos=accessor(source.attributes.POSITION),norm=accessor(source.attributes.NORMAL),uv=accessor(source.attributes.TEXCOORD_0),indices=accessor(source.indices);
const baseImage=doc.images[doc.textures[doc.materials[0].pbrMetallicRoughness.baseColorTexture.index].source],bv=doc.bufferViews[baseImage.bufferView];const decoded=await sharp(oldBinary.subarray(bv.byteOffset,bv.byteOffset+bv.byteLength)).removeAlpha().raw().toBuffer({resolveWithObject:true});
function sample(u,v){const x=Math.min(decoded.info.width-1,Math.max(0,Math.floor(u*decoded.info.width))),y=Math.min(decoded.info.height-1,Math.max(0,Math.floor(v*decoded.info.height))),i=(y*decoded.info.width+x)*decoded.info.channels;return [decoded.data[i],decoded.data[i+1],decoded.data[i+2]];}
function protectedRegion(x,y,z){
 // Original wheels and cabin glazing remain textured materials, not painted carbon.
 if(Math.abs(z)>.135&&([-.28,.78].some(cx=>(x-cx)**2+(y+.395)**2<.169**2)))return 'wheel';
 if(x>-.115&&x<.17&&y>-.19&&y<.015)return 'cab_glazing';
 for(const side of [-1,1])if((x+.7421)**2+(y-.327)**2+(z-side*.0874)**2<.022**2)return 'spreader_pin';
 // Keep the polished raising rods at their original connections even in shaded texels.
 for(const side of [-1,1]){const a=new THREE.Vector3(.325,.172,side*.115),b=new THREE.Vector3(.005,-.30,side*.115),point=new THREE.Vector3(x,y,z),ab=b.clone().sub(a),t=THREE.MathUtils.clamp(point.clone().sub(a).dot(ab)/ab.lengthSq(),0,1);if(point.distanceToSquared(a.addScaledVector(ab,t))<.018**2&&y>-.025)return 'polished_rod';}
 return null;
}
function faceCarbon(ids){const p=[0,0,0];for(const id of ids)for(let k=0;k<3;k++)p[k]+=pos[id*3+k]/3;const region=protectedRegion(...p);if(region)return {carbon:false,region};
 const samples=ids.map(id=>sample(uv[id*2],uv[id*2+1]));samples.push(sample(ids.reduce((s,i)=>s+uv[i*2]/3,0),ids.reduce((s,i)=>s+uv[i*2+1]/3,0)));
 // Protect blue/cyan paint and glass, warm safety markers, and bright metallic details.
 const painted=samples.some(([r,g,b])=>r>120&&g>80&&b<g*.7)||samples.slice(-1).some(([r,g,b])=>b-r>=35&&b>g*1.1);
 const deck=p[0]>-.40&&p[0]<.70&&p[1]>-.275&&p[1]<-.14&&Math.abs(p[2])<.25;
 const spreader=p[0]<-.72&&p[1]>.12;
 // Bright neutral patches on structural deck/spreader are baked illumination,
 // not a second paint. Preserve protected pin/rod volumes and colored markers.
 const feature=painted||(!deck&&!spreader&&samples.filter(([r,g,b])=>Math.max(r,g,b)>190&&Math.min(r,g,b)>165).length>=3);
 if(feature)return {carbon:false,region:'paint_metal_marker'};
 // Dark neutral painted surfaces in chassis, structural deck, spreader and hinge casing.
 const neutral=samples.filter(([r,g,b])=>Math.max(r,g,b)-Math.min(r,g,b)<60).length>=3;
 return {carbon:neutral,region:neutral?'carbon':'other'};
}
const keep=[],carbonIds=[],counts={};for(let i=0;i<indices.length;i+=3){const ids=[indices[i],indices[i+1],indices[i+2]],c=faceCarbon(ids);(c.carbon?carbonIds:keep).push(...ids);counts[c.region]=(counts[c.region]||0)+1;}
// World-density face projections avoid atlas-dependent grain scale differences.
const density=6/(.9408590198+.9435049891)*(12/.7);
function projected(p,n){const axis=Math.abs(n[0])>Math.abs(n[1])?(Math.abs(n[0])>Math.abs(n[2])?0:2):(Math.abs(n[1])>Math.abs(n[2])?1:2);return axis===0?[p[2]*density,p[1]*density]:axis===1?[p[0]*density,p[2]*density]:[p[0]*density,p[1]*density];}
function carbonPrimitive(ids,positions,normals){const p=[],n=[],v=[];for(let i=0;i<ids.length;i+=3){const a=ids.slice(i,i+3),A=new THREE.Vector3().fromArray(positions,a[0]*3),B=new THREE.Vector3().fromArray(positions,a[1]*3),C=new THREE.Vector3().fromArray(positions,a[2]*3),fn=B.clone().sub(A).cross(C.clone().sub(A)).normalize().toArray();for(const id of a){const pp=Array.from(positions.subarray(id*3,id*3+3)),nn=Array.from(normals.subarray(id*3,id*3+3));p.push(...pp);n.push(...nn);v.push(...projected(pp,fn));}}return {attributes:{POSITION:append(new Float32Array(p),'VEC3',34962),NORMAL:append(new Float32Array(n),'VEC3',34962),TEXCOORD_0:append(new Float32Array(v),'VEC2',34962)},material,mode:4};}
const carbon=carbonPrimitive(carbonIds,pos,norm),newMesh=doc.meshes.length;doc.meshes.push({name:'Original lift — selective carbon and retained materials',primitives:[{...source,indices:append(new Uint32Array(keep),'SCALAR',34963)},carbon]});doc.nodes[0].mesh=newMesh;
let repaired=0;for(let i=1;i<doc.meshes.length-1;i++){const mesh=doc.meshes[i];mesh.primitives=mesh.primitives.map(p=>{if(p.material!==1&&p.material!==4)return p;const pp=accessor(p.attributes.POSITION),nn=accessor(p.attributes.NORMAL),ii=p.indices?Array.from(accessor(p.indices)):Array.from({length:pp.length/3},(_,i)=>i);repaired++;return carbonPrimitive(ii,pp,nn);});}
doc.buffers[0].byteLength=offset;const js=Buffer.from(JSON.stringify(doc)),jp=Buffer.concat([js,Buffer.alloc((4-js.length%4)%4,32)]),bin=Buffer.concat(chunks),h=Buffer.alloc(12),jh=Buffer.alloc(8),bh=Buffer.alloc(8);h.write('glTF');h.writeUInt32LE(2,4);h.writeUInt32LE(28+jp.length+bin.length,8);jh.writeUInt32LE(jp.length);jh.writeUInt32LE(0x4e4f534a,4);bh.writeUInt32LE(bin.length);bh.writeUInt32LE(0x004e4942,4);const out=Buffer.concat([h,jh,jp,bh,bin]);fs.writeFileSync(new URL('model-carbon-unified.glb',dir),out);
const report={date_local:'2026-10-05',input_sha256:hash(input),output_sha256:hash(out),output_bytes:out.length,carbon_material:material,approved_srgb:'#11151B',metalness:.35,roughness:.5,emission:0,normal_scale:.12,grain_sha256:hash(png),carbon_original_triangles:carbonIds.length/3,retained_original_triangles:keep.length/3,classification:counts,repaired_primitives_unified:repaired,total_triangles:55538,original_binary_prefix_preserved:bin.subarray(0,bl).equals(oldBinary),geometry_positions_changed:0,geometry_normals_changed:0,triangle_topology_changed:0,accepted_geometry_preserved:true,other_materials_modified:0,paid_jobs_added:0,rigging:false,model_visual_approval:'pending',classification_limits:'Cab glazing and wheels protected spatially; painted blue/cyan, metal and safety markers protected by per-face atlas samples. Inspect material boundaries in rendered review.'};fs.writeFileSync(new URL('carbon-amendment.json',dir),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
