import fs from 'node:fs';
import crypto from 'node:crypto';
import * as T from 'three';
const directory=new URL('./',import.meta.url),base=fs.readFileSync(new URL('model-entry-amended.glb',directory));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const expected='7dfe2a7b627705f0449629cc488dad11b895e490e8cae9ac921e581b1b3e9e84';
if(hash(base)!==expected)throw new Error('Approved cab-entry draft input changed');
const jlen=base.readUInt32LE(12),doc=JSON.parse(base.subarray(20,20+jlen).toString()),start=28+jlen,blen=base.readUInt32LE(20+jlen);
const chunks=[base.subarray(start,start+blen)];let offset=blen;const parts=[];
function readAccessor(id){const a=doc.accessors[id],v=doc.bufferViews[a.bufferView],o=base.byteOffset+start+(v.byteOffset||0)+(a.byteOffset||0);return a.componentType===5126?new Float32Array(base.buffer,o,a.count*(a.type==='VEC3'?3:2)):new Uint32Array(base.buffer,o,a.count);}
function append(array,target,type){const bytes=Buffer.from(array.buffer,array.byteOffset,array.byteLength),vi=doc.bufferViews.length;doc.bufferViews.push({buffer:0,byteOffset:offset,byteLength:bytes.length,target});chunks.push(bytes);offset+=bytes.length;const pad=(4-offset%4)%4;if(pad){chunks.push(Buffer.alloc(pad));offset+=pad;}const a={bufferView:vi,componentType:array instanceof Float32Array?5126:5125,count:array.length/(type==='VEC3'?3:1),type};if(type==='VEC3'){a.min=[Infinity,Infinity,Infinity];a.max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<array.length;i++){let k=i%3;a.min[k]=Math.min(a.min[k],array[i]);a.max[k]=Math.max(a.max[k],array[i]);}}const ai=doc.accessors.length;doc.accessors.push(a);return ai;}
const originalPrimitive=doc.meshes[0].primitives[0],positions=readAccessor(originalPrimitive.attributes.POSITION),indices=readAccessor(originalPrimitive.indices);
const graphiteIndex=doc.materials.findIndex(m=>m.name==='Pivot graphite casing');if(graphiteIndex<0)throw new Error('Approved graphite material not found');
const axisY=x=>.24086-.3173*x;
function near(x,y,z,c,r){return (x-c[0])**2+(y-c[1])**2+(z-c[2])**2<r*r;}
function protectedPoint(x,y,z){
 for(const side of[-1,1]){
  if(near(x,y,z,[.325,.173,side*.115],.024)||near(x,y,z,[-.7421,.327,side*.0874],.022)||near(x,y,z,[-.7033,.425,side*.0848],.023))return true;
  // Exposed rod at the main raising hinge remains metal and connected.
  const a=new T.Vector3(.325,.172,side*.115),b=new T.Vector3(.005,-.30,side*.115),p=new T.Vector3(x,y,z),ab=b.clone().sub(a),t=T.MathUtils.clamp(p.clone().sub(a).dot(ab)/ab.lengthSq(),0,1);
  if(p.distanceToSquared(a.addScaledVector(ab,t))<.018**2)return true;
  if(near(x,y,z,[.669,-.08,side*.091],.029))return true;
 }
 return x>.61&&y<-.023&&y>-.17&&Math.abs(z)>.075; // Preserve blue rear hinge cheeks.
}
function casingPoint(x,y,z){
 const along=x>-.735&&x<.79&&Math.abs(y-axisY(x))<.11&&Math.abs(z)<.154;
 const joint=x>.245&&x<.445&&y>.03&&y<.24&&Math.abs(z)<.145;
 const heel=x>.61&&x<.79&&y>-.14&&y<.115&&Math.abs(z)<.09;
 const head=x>-.81&&x<-.63&&y>.301&&y<.559&&Math.abs(z)<.104;
 return along||joint||heel||head;
}
const retained=[],removed=[];
for(let i=0;i<indices.length;i+=3){let affected=false,c=[0,0,0];for(let k=0;k<3;k++){const v=indices[i+k]*3,x=positions[v],y=positions[v+1],z=positions[v+2];affected ||= casingPoint(x,y,z);c[0]+=x/3;c[1]+=y/3;c[2]+=z/3;}const protect=protectedPoint(...c);const list=affected&&!protect?removed:retained;list.push(indices[i],indices[i+1],indices[i+2]);}
const newIndex=append(new Uint32Array(retained),34963,'SCALAR');
const filteredMesh=doc.meshes.length;doc.meshes.push({name:'Lift_Outside_Boom_Casing',primitives:[{...originalPrimitive,indices:newIndex}]});
// The original accessor and all prior bytes remain embedded for a same-camera comparison.
doc.nodes[0].mesh=filteredMesh;doc.nodes[0].extras={...(doc.nodes[0].extras||{}),original_index_accessor:originalPrimitive.indices,boom_filtered:true};
function addPart(name,g,extras={},material=graphiteIndex){const v=g.index?g.toNonIndexed():g;v.computeVertexNormals();const pos=append(v.attributes.position.array,34962,'VEC3'),norm=append(v.attributes.normal.array,34962,'VEC3'),mi=doc.meshes.length;doc.meshes.push({name,primitives:[{attributes:{POSITION:pos,NORMAL:norm},material,mode:4}]});const ni=doc.nodes.length;doc.nodes.push({name,mesh:mi,extras});children.push(ni);parts.push({name,triangles:v.attributes.position.count/3,...extras});}
// Closed eight-sided chamfered rectangular lofts. Each section has both end caps;
// overlapping shoulders retain continuous coverage without exposed cut planes.
function beam(xa,xb,ha,hb,wa,wb){
 const A=new T.Vector3(xa,axisY(xa),0),B=new T.Vector3(xb,axisY(xb),0),u=B.clone().sub(A).normalize(),up=new T.Vector3(u.y,-u.x,0).normalize();if(up.y<0)up.negate();
 const vertices=[],indices=[];
 function ring(c,h,w){const by=Math.min(.005,h*.12),bz=Math.min(.005,w*.12);const corners=[[-w/2+ bz,h/2],[w/2-bz,h/2],[w/2,h/2-by],[w/2,-h/2+by],[w/2-bz,-h/2],[-w/2+bz,-h/2],[-w/2,-h/2+by],[-w/2,h/2-by]];for(const[z,y]of corners)vertices.push(...c.clone().addScaledVector(up,y).add(new T.Vector3(0,0,z)).toArray());}
 ring(A,ha,wa);ring(B,hb,wb);vertices.push(...A.toArray(),...B.toArray());
 for(let i=0;i<8;i++){let j=(i+1)%8;indices.push(i,j,8+j,i,8+j,8+i);indices.push(16,j,i,17,8+i,8+j);}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setIndex(indices.flatMap((_,i)=>i%3===0?[indices[i],indices[i+2],indices[i+1]]:[]));g.computeVertexNormals();return g;
}
const children=[];
const sections=[{name:'Boom_Main_Carbon_Shell',x:[.738,-.373],h:[.104,.14],w:[.131,.126]},{name:'Boom_Middle_Carbon_Shell',x:[-.336,-.574],h:[.133,.124],w:[.116,.111]},{name:'Boom_End_Carbon_Shell',x:[-.544,-.713],h:[.114,.107],w:[.102,.096]}];
for(const s of sections)addPart(s.name,beam(...s.x,...s.h,...s.w),{scope:'Closed full-length graphite casing',section:s});
for(const [name,x,h,w]of[['Main telescopic shoulder',-.354,.146,.138],['End telescopic shoulder',-.558,.131,.119]])addPart(name.replaceAll(' ','_'),beam(x+.009,x-.009,h,h,w,w),{scope:'Closed overlapping graphite shoulder'});
function extruded(outline,depth){const s=new T.Shape();outline.forEach(([x,y],i)=>i?s.lineTo(x,y):s.moveTo(x,y));s.closePath();const g=new T.ExtrudeGeometry(s,{depth,bevelEnabled:true,bevelThickness:.002,bevelSize:.002,bevelSegments:2,steps:1});g.translate(0,0,-depth/2);return g;}
addPart('Boom_Graphite_Hydraulic_Gusset',extruded([[.262,.178],[.285,.210],[.360,.190],[.408,.039],[.344,.061],[.291,.083],[.264,.119]],.17),{scope:'Graphite joint casing around retained metal hinge/rod'});
addPart('Boom_Graphite_Front_Head',extruded([[-.649,.510],[-.676,.549],[-.717,.549],[-.789,.341],[-.787,.312],[-.747,.305],[-.7,.359],[-.657,.460]],.15),{scope:'Closed graphite front mounting plate joining the beam to retained spreader pivot'});
addPart('Boom_Graphite_Rear_Heel',extruded([[.615,.024],[.695,.083],[.756,.06],[.765,-.043],[.711,-.112],[.666,-.112],[.647,-.058]],.13),{scope:'Closed rear boom casing behind preserved blue hinge cheeks'});
const titaniumIndex=doc.materials.findIndex(m=>m.name==='Pivot fastener titanium');
for(const side of[-1,1]){
 const boss=new T.CylinderGeometry(.0245,.0245,.044,32);boss.rotateX(Math.PI/2);boss.translate(.289,.197,side*.106);addPart(`Boom_Upper_Pivot_Boss_${side}`,boss,{scope:'Closed graphite mounting boss at the original upper-pin location'});
 const pin=new T.CylinderGeometry(.010,.010,.006,12);pin.rotateX(Math.PI/2);pin.translate(.289,.197,side*.131);addPart(`Boom_Upper_Pivot_Pin_${side}`,pin,{scope:'Brushed titanium pin cap at retained original connection center'},titaniumIndex);
}
const parent=doc.nodes.length;doc.nodes.push({name:'Boom_Coverage_Repair',children,extras:{scope:'User-authorized full-length carbon coverage repair; static pose, no rig'}});doc.scenes[doc.scene||0].nodes.push(parent);doc.buffers[0].byteLength=offset;
const json=Buffer.from(JSON.stringify(doc)),jp=Buffer.concat([json,Buffer.alloc((4-json.length%4)%4,32)]),binary=Buffer.concat(chunks),head=Buffer.alloc(12);head.write('glTF');head.writeUInt32LE(2,4);head.writeUInt32LE(28+jp.length+binary.length,8);const jh=Buffer.alloc(8);jh.writeUInt32LE(jp.length,0);jh.writeUInt32LE(0x4e4f534a,4);const bh=Buffer.alloc(8);bh.writeUInt32LE(binary.length,0);bh.writeUInt32LE(0x004e4942,4);const out=Buffer.concat([head,jh,jp,bh,binary]);fs.writeFileSync(new URL('model-boom-amended.glb',directory),out);
const added=parts.reduce((s,p)=>s+p.triangles,0),report={date_local:'2026-10-05',authorization:'Make the arm totally filled with the same carbon material throughout its length',reported_camera:{azimuth:124.6,elevation:7,distance:2.66},scope:'Replace damaged arm casing faces with closed full-length graphite beam sections, shoulders, hydraulic gusset and rear heel; retain exposed connections and accepted cab entry',base_sha256:expected,amended_sha256:hash(out),amended_bytes:out.length,original_binary_prefix_preserved:binary.subarray(0,blen).equals(chunks[0]),original_texture_bytes_modified:0,approved_cab_entry_nodes_modified:0,original_index_accessor:originalPrimitive.indices,filtered_index_accessor:newIndex,removed_casing_triangles:removed.length/3,retained_original_triangles:retained.length/3,added_boom_triangles:added,total_triangles:81977-removed.length/3+added,material:doc.materials[graphiteIndex],parts,axis_equation:'y = 0.24086 - 0.3173*x in original normalized model space',comparison:'Restore embedded original indices and hide new boom nodes; previous variants remain separate immutable files',paid_generation_jobs:0,rigging:false,visual_approval:'pending'};fs.writeFileSync(new URL('boom-amendment.json',directory),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({amended_sha256:report.amended_sha256,removed:report.removed_casing_triangles,added,total:report.total_triangles}));
