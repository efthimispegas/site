import fs from 'node:fs';
import crypto from 'node:crypto';
import * as T from 'three';

const directory = new URL('./', import.meta.url);
const original = fs.readFileSync(new URL('model.glb', directory));
const expected = '6b95034bbb1471cffa167b1681f97fee5334f24e2ad3b8bb79d0cf6c88eabb9a';
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
if (hash(original) !== expected) throw new Error('Original draft hash changed');
const jsonLength = original.readUInt32LE(12);
const document = JSON.parse(original.subarray(20, 20 + jsonLength).toString());
const binaryStart = 28 + jsonLength;
const binaryLength = original.readUInt32LE(20 + jsonLength);
const buffers = [original.subarray(binaryStart, binaryStart + binaryLength)];
let offset = binaryLength;
const additions = [];
const append = (array, target, type) => {
  const buffer = Buffer.from(array.buffer, array.byteOffset, array.byteLength);
  const view = document.bufferViews.length;
  document.bufferViews.push({buffer:0,byteOffset:offset,byteLength:buffer.length,target});
  buffers.push(buffer);offset += buffer.length;
  const pad=(4-offset%4)%4;if(pad){buffers.push(Buffer.alloc(pad));offset+=pad;}
  const componentType=array instanceof Float32Array?5126:5125;
  const count=array.length/(type==='VEC3'?3:1);
  const accessor={bufferView:view,componentType,count,type};
  if(type==='VEC3'&&target===34962){accessor.min=[Infinity,Infinity,Infinity];accessor.max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<array.length;i++){const axis=i%3;accessor.min[axis]=Math.min(accessor.min[axis],array[i]);accessor.max[axis]=Math.max(accessor.max[axis],array[i]);}}
  const id=document.accessors.length;document.accessors.push(accessor);return id;
};
const graphiteIndex=document.materials.length;
document.materials.push({name:'Pivot graphite casing',pbrMetallicRoughness:{baseColorFactor:[...new T.Color('#202A36').toArray(),1],metallicFactor:.35,roughnessFactor:.5},doubleSided:false});
const titaniumIndex=document.materials.length;
document.materials.push({name:'Pivot fastener titanium',pbrMetallicRoughness:{baseColorFactor:[...new T.Color('#9DA9B5').toArray(),1],metallicFactor:.82,roughnessFactor:.3},doubleSided:false});
function primitive(geometry,name,material){
  const g=geometry.index?geometry.toNonIndexed():geometry;g.computeVertexNormals();
  const position=append(g.attributes.position.array,34962,'VEC3');
  const normal=append(g.attributes.normal.array,34962,'VEC3');
  additions.push({name,triangles:g.attributes.position.count/3,material});
  return {attributes:{POSITION:position,NORMAL:normal},material,mode:4};
}
// Small closed casing/gusset around the existing hydraulic attachment.
// Coordinates are in the original model space; no global geometry or textures are changed.
const outline=[[.262,.178],[.285,.210],[.360,.190],[.408,.039],[.344,.061],[.291,.083],[.264,.119]];
const shape=new T.Shape();outline.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
const shell=new T.ExtrudeGeometry(shape,{depth:.17,bevelEnabled:true,bevelThickness:.002,bevelSize:.002,bevelSegments:2,steps:1});shell.translate(0,0,-.085);
const primitives=[primitive(shell,'Closed graphite pivot casing',graphiteIndex)];
const meshIndex=document.meshes.length;document.meshes.push({name:'Pivot_Coverage_Repair',primitives});
const nodeIndex=document.nodes.length;document.nodes.push({name:'Pivot_Coverage_Repair',mesh:meshIndex,extras:{scope:'Authorized localized graphite coverage amendment; no mechanical rig'}});
document.scenes[document.scene||0].nodes.push(nodeIndex);
const hoseIndex=document.materials.length;
document.materials.push({name:'Rear hydraulic hose rubber',pbrMetallicRoughness:{baseColorFactor:[...new T.Color('#0C1016').toArray(),1],metallicFactor:.02,roughnessFactor:.82},doubleSided:false});
const hosePrimitives=[],hoseRoutes=[];
const sourceGeometry=new T.BufferGeometry();
for(const [name,id,width] of [['position',0,3]]){const a=document.accessors[id],v=document.bufferViews[a.bufferView];sourceGeometry.setAttribute(name,new T.BufferAttribute(new Float32Array(original.buffer,original.byteOffset+binaryStart+(v.byteOffset||0)+(a.byteOffset||0),a.count*width),width));}
const ia=document.accessors[3],iv=document.bufferViews[ia.bufferView];sourceGeometry.setIndex(new T.BufferAttribute(new Uint32Array(original.buffer,original.byteOffset+binaryStart+iv.byteOffset,ia.count),1));
const sourceMesh=new T.Mesh(sourceGeometry,new T.MeshBasicMaterial({side:T.DoubleSide}));sourceMesh.updateMatrixWorld();
for(const side of [-1,1])for(let strand=0;strand<2;strand++){
  const dx=strand*.015,dz=strand*.012;
  const route=[[.703,.026,.085],[.741,.019,.125],[.757,-.043,.15],[.733,-.118,.167],[.678,-.18,.17],[.643,-.22,.155]].map(([x,y,z])=>[x+dx,y,z*side+dz*side]);
  // Seat the lower fitting on the original chassis surface, rather than ending in space.
  const last=route.at(-1),bodyHit=new T.Raycaster(new T.Vector3(last[0],-.15,last[2]),new T.Vector3(0,-1,0)).intersectObject(sourceMesh)[0];
  if(!bodyHit)throw new Error('No chassis surface for hose port');last[1]=bodyHit.point.y+.005;
  const port=new T.BoxGeometry(.023,.01,.024);port.translate(last[0],bodyHit.point.y+.003,last[2]);hosePrimitives.push(primitive(port,'Chassis hose mounting port',graphiteIndex));
  const points=route.map(p=>new T.Vector3(...p));
  const curve=new T.CatmullRomCurve3(points,false,'centripetal');
  hosePrimitives.push(primitive(new T.TubeGeometry(curve,48,.0043,8,false),`Rear hose ${side<0?'right':'left'} ${strand+1}`,hoseIndex));
  for(const end of [0,1]){
    const at=curve.getPoint(end),tangent=curve.getTangent(end).normalize();
    const ferrule=new T.CylinderGeometry(.0068,.0068,.013,12,1);
    ferrule.applyQuaternion(new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),tangent));ferrule.translate(...at.toArray());
    hosePrimitives.push(primitive(ferrule,'Dark hose connector',graphiteIndex));
  }
  hoseRoutes.push({side:side<0?'right':'left',strand:strand+1,points:route,radius:.0043});
}
const hoseMeshIndex=document.meshes.length;document.meshes.push({name:'Rear_Hydraulic_Hoses_Repair',primitives:hosePrimitives});
const hoseNodeIndex=document.nodes.length;document.nodes.push({name:'Rear_Hydraulic_Hoses_Repair',mesh:hoseMeshIndex,extras:{scope:'Rear boom to body hose coverage requested by user; static draft, future endpoint-driven deformation awaits rig approval'}});
document.scenes[document.scene||0].nodes.push(hoseNodeIndex);
document.buffers[0].byteLength=offset;
const json=Buffer.from(JSON.stringify(document));const jsonPad=Buffer.concat([json,Buffer.alloc((4-json.length%4)%4,32)]);
const binary=Buffer.concat(buffers);const header=Buffer.alloc(12);header.write('glTF');header.writeUInt32LE(2,4);header.writeUInt32LE(28+jsonPad.length+binary.length,8);
const jsonHeader=Buffer.alloc(8);jsonHeader.writeUInt32LE(jsonPad.length,0);jsonHeader.writeUInt32LE(0x4e4f534a,4);
const binHeader=Buffer.alloc(8);binHeader.writeUInt32LE(binary.length,0);binHeader.writeUInt32LE(0x004e4942,4);
const amended=Buffer.concat([header,jsonHeader,jsonPad,binHeader,binary]);fs.writeFileSync(new URL('model-pivot-amended.glb',directory),amended);
const manifest={date_local:'2026-10-05',authorization:['Proceed with the amendment of the material around that area','The 3d model is also missing the cables connecting the arm’s rear end to the main body'],scope:'Localized boom/hydraulic pivot graphite casing and rear hydraulic hoses; existing pivot bosses and fasteners retained; original mesh/textures preserved',original_sha256:expected,amended_sha256:hash(amended),amended_bytes:amended.length,original_binary_prefix_preserved:binary.subarray(0,binaryLength).equals(buffers[0]),original_vertices_and_indices_modified:0,original_texture_bytes_modified:0,outline_model_coordinates:outline,repair_depth:.17,hose_routes:hoseRoutes,additions,added_triangles:additions.reduce((s,x)=>s+x.triangles,0),graphite:{srgb:'#202A36',metallic:.35,roughness:.5,emissive:0},hose_material:{srgb:'#0C1016',metallic:.02,roughness:.82,emissive:0},hydraulic_rod:'Original polished rod geometry and material retained; no global repaint',paid_generation_jobs:0,rigging:false,visual_approval:'pending'};
fs.writeFileSync(new URL('pivot-amendment.json',directory),JSON.stringify(manifest,null,2)+'\n');console.log(JSON.stringify({amended_sha256:manifest.amended_sha256,added_triangles:manifest.added_triangles,original_binary_prefix_preserved:manifest.original_binary_prefix_preserved}));
