import fs from 'node:fs';
import crypto from 'node:crypto';
import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';

const directory=new URL('./',import.meta.url);
const base=fs.readFileSync(new URL('model-pivot-amended.glb',directory));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const baseHash='fb3ed9995f2d8d9f2549704684f6f33868e7f688bd56a9a30138a6bc55940bd9';
if(hash(base)!==baseHash)throw new Error('Pivot/hose amendment input changed');
const jlen=base.readUInt32LE(12),doc=JSON.parse(base.subarray(20,20+jlen).toString());
const binaryStart=28+jlen,binaryLength=base.readUInt32LE(20+jlen);
const chunks=[base.subarray(binaryStart,binaryStart+binaryLength)];let offset=binaryLength;
const parts=[];
function append(array){const bytes=Buffer.from(array.buffer,array.byteOffset,array.byteLength),view=doc.bufferViews.length;doc.bufferViews.push({buffer:0,byteOffset:offset,byteLength:bytes.length,target:34962});chunks.push(bytes);offset+=bytes.length;const pad=(4-offset%4)%4;if(pad){chunks.push(Buffer.alloc(pad));offset+=pad;}const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<array.length;i++){let k=i%3;min[k]=Math.min(min[k],array[i]);max[k]=Math.max(max[k],array[i]);}const id=doc.accessors.length;doc.accessors.push({bufferView:view,componentType:5126,count:array.length/3,type:'VEC3',min,max});return id;}
function material(name,srgb,metallic,roughness){const index=doc.materials.length;doc.materials.push({name,pbrMetallicRoughness:{baseColorFactor:[...new T.Color(srgb).toArray(),1],metallicFactor:metallic,roughnessFactor:roughness},doubleSided:false});return index;}
const graphite=material('Cab access graphite frame','#26303C',.6,.42);
const tread=material('Anti-slip brushed steel treads','#6B798A',.8,.47);
const rail=material('Exterior tubular gunmetal handrails','#3C4857',.85,.28);
const bright=material('Step nosing and mounting steel','#9DA9B5',.88,.32);
const children=[];
function box(w,h,d,x,y,z){const g=new T.BoxGeometry(w,h,d);g.translate(x,y,z);return g;}
function tube(a,b,r=.0033){const start=new T.Vector3(...a),end=new T.Vector3(...b);return new T.TubeGeometry(new T.LineCurve3(start,end),1,r,12,false);}
function combined(name,groups,extras={}){
 const primitives=[];let triangles=0;
 for(const [material,geometries] of groups){if(!geometries.length)continue;const merged=mergeGeometries(geometries.map(g=>{const v=g.index?g.toNonIndexed():g;v.deleteAttribute('uv');return v;}));merged.computeVertexNormals();const pos=append(merged.attributes.position.array),norm=append(merged.attributes.normal.array);primitives.push({attributes:{POSITION:pos,NORMAL:norm},material,mode:4});triangles+=merged.attributes.position.count/3;}
 const mi=doc.meshes.length;doc.meshes.push({name,primitives});const ni=doc.nodes.length;doc.nodes.push({name,mesh:mi,extras});children.push(ni);parts.push({name,triangles,...extras});
}
const layouts=[];
for(const side of [-1,1]){
 const label=side<0?'Right':'Left',cx=-.001;
 const stepYs=[-.326,-.381,-.436];
 // Three climb steps below a separate landing. Narrow raised ribs and a bright front
 // nosing make each independent tread readable at website scale.
 for(let level=0;level<3;level++){
  const y=stepYs[level],z=side*(.252+level*.008),under=[box(.082,.008,.056,cx,y,z)];
  const ribs=[];for(let k=0;k<9;k++)ribs.push(box(.0032,.0024,.042,cx-.032+k*.008,y+.0052,z));
  const nose=[box(.082,.0035,.004,cx,y+.003,z+side*.0275)];
  combined(`${label}_Entry_Step_${level+1}`,[[graphite,under],[tread,ribs],[bright,nose]],{side:label,step:level+1,center:[cx,y,z],width:.082,depth:.056,scope:'Cab step definition requested by user'});
 }
 const frame=[box(.086,.167,.006,cx,-.381,side*.24)];
 for(const x of[cx-.044,cx+.044]){
  frame.push(box(.006,.177,.011,x,-.384,side*.259));
  for(const y of[stepYs[0],stepYs[2]])frame.push(box(.006,.01,.044,x,y,side*.233));
 }
 combined(`${label}_Entry_Step_Supports`,[[graphite,frame]]);
 const landing=[box(.269,.007,.117,.005,-.29,side*.2115)];
 const landingRibs=[];for(let k=0;k<25;k++)landingRibs.push(box(.0026,.0018,.106,-.119+k*.0103,-.2856,side*.2115));
 combined(`${label}_Cab_Landing`,[[graphite,landing],[tread,landingRibs]],{scope:'Separate upper landing; not counted as a fourth climb step'});
 const z=side*.266,railOutline=[[.138,-.285,z],[.138,-.143,z],[.12,-.108,z],[-.112,-.108,z],[-.132,-.126,z],[-.132,-.285,z]];
 const tubes=[];for(let k=1;k<railOutline.length;k++)tubes.push(tube(railOutline[k-1],railOutline[k]));
 for(const y of[-.183,-.255])tubes.push(tube([-.132,y,z],[.138,y,z],.0028));
 tubes.push(tube([.012,-.285,z],[.012,-.108,z],.003));
 // Rounded connections retain the tubular profile seen in both approved side plates.
 for(const p of railOutline.slice(1,-1)){const joint=new T.SphereGeometry(.0033,12,6);joint.translate(...p);tubes.push(joint);}
 const mounts=[];for(const x of[-.132,.012,.138])mounts.push(box(.014,.006,.017,x,-.284,z));
 combined(`${label}_Exterior_Handrails`,[[rail,tubes],[bright,mounts]],{scope:'Tubular metallic cab-entry rails from accepted side references',outline:railOutline});
 const anchorZ=side<0?-.073:.1905,gripZ=anchorZ+side*.025,gripX=.010;
 const grip=[tube([gripX,-.206,gripZ],[gripX,-.153,gripZ],.0028),tube([gripX,-.206,anchorZ],[gripX,-.206,gripZ],.0026),tube([gripX,-.153,anchorZ],[gripX,-.153,gripZ],.0026)];
 const anchors=[box(.009,.008,.006,gripX,-.206,anchorZ),box(.009,.008,.006,gripX,-.153,anchorZ)];
 combined(`${label}_Door_Grab_Handle`,[[rail,grip],[bright,anchors]],{scope:'Exterior door-pillar metallic grab handle'});
 layouts.push({side:label,step_centers:stepYs.map((y,i)=>[cx,y,side*(.252+i*.008)]),landing_y:-.29,rail_z:z,door_grip_z:gripZ});
}
const parent=doc.nodes.length;doc.nodes.push({name:'Cab_Entry_Repair',children,extras:{scope:'User-authorized three steps and exterior metallic handles on right/left; static local amendment, no rig'}});doc.scenes[doc.scene||0].nodes.push(parent);doc.buffers[0].byteLength=offset;
const json=Buffer.from(JSON.stringify(doc)),jpad=Buffer.concat([json,Buffer.alloc((4-json.length%4)%4,32)]),binary=Buffer.concat(chunks);
const header=Buffer.alloc(12);header.write('glTF');header.writeUInt32LE(2,4);header.writeUInt32LE(28+jpad.length+binary.length,8);const jh=Buffer.alloc(8);jh.writeUInt32LE(jpad.length,0);jh.writeUInt32LE(0x4e4f534a,4);const bh=Buffer.alloc(8);bh.writeUInt32LE(binary.length,0);bh.writeUInt32LE(0x004e4942,4);
const output=Buffer.concat([header,jh,jpad,bh,binary]);fs.writeFileSync(new URL('model-entry-amended.glb',directory),output);
const added=parts.reduce((s,p)=>s+p.triangles,0);const evidence={date_local:'2026-10-05',authorization:'Pay close attention to the approved static assets right/left side and add the three steps and metallic handles outside the driver’s door',scope:'Three distinct anti-slip climb steps, supports, separate landing, tubular exterior rails and door-pillar grip on each side',reference_files:['../../L01/L01-side.png','../lift-left.png'],base_sha256:baseHash,amended_sha256:hash(output),amended_bytes:output.length,base_binary_prefix_preserved:binary.subarray(0,binaryLength).equals(chunks[0]),original_mesh_and_textures_modified:0,pivot_and_hoses_modified:0,layouts,parts,entry_added_triangles:added,added_triangles:added+3584,paid_generation_jobs:0,rigging:false,visual_approval:'pending'};fs.writeFileSync(new URL('entry-amendment.json',directory),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify({sha256:evidence.amended_sha256,entry_triangles:added,total_triangles:75201+evidence.added_triangles}));
