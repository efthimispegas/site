"""Preserve original approved-job outputs and inspect their GLB structure without editing geometry."""
from pathlib import Path
import hashlib
import json
import struct
import urllib.request
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
OUT = BASE / 'model-draft'
OUT.mkdir(exist_ok=True)

def unwrap(data):
    if 'content' in data:
        return json.loads(next(c['text'] for c in data['content'] if c.get('type') == 'text' and c.get('text', '').lstrip().startswith('{')))
    return data

response = unwrap(json.loads((BASE / 'model-draft-result.json').read_text()))
result = response.get('result', response.get('data', response))
if 'model_glb' not in result:
    raise ValueError('Completed response contains no model_glb; inspect saved result before continuing')
downloads = []

def preserve(file, relative):
    path = OUT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        request = urllib.request.Request(file['url'], headers={'User-Agent': 'PegasoftConceptReview/1.0'})
        with urllib.request.urlopen(request, timeout=120) as source:
            data = source.read()
        path.write_bytes(data)
    data = path.read_bytes()
    downloads.append({'file': relative, 'url': file['url'], 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    return data

blob = preserve(result['model_glb'], 'model.glb')
for i, group in enumerate(result.get('texture_urls', [])):
    for kind, file in group.items():
        if file and file.get('url'):
            preserve(file, f'textures/{i}-{kind}.png')
if result.get('thumbnail'):
    preserve(result['thumbnail'], 'thumbnail.png')

magic, version, length = struct.unpack_from('<4sII', blob)
assert magic == b'glTF' and version == 2 and length == len(blob), 'Invalid GLB header'
offset = 12
document = None
while offset < length:
    size, kind = struct.unpack_from('<II', blob, offset)
    payload = blob[offset+8:offset+8+size]
    assert len(payload) == size
    if kind == 0x4E4F534A:
        document = json.loads(payload.decode('utf8'))
    offset += 8 + size
assert document and offset == length
accessors = document.get('accessors', [])
primitives = []
for mi, mesh in enumerate(document.get('meshes', [])):
    for pi, primitive in enumerate(mesh['primitives']):
        positions = accessors[primitive['attributes']['POSITION']]
        indices = accessors[primitive['indices']] if 'indices' in primitive else None
        count = indices['count'] if indices else positions['count']
        primitives.append({'mesh': mi, 'primitive': pi, 'name': mesh.get('name'), 'vertices': positions['count'], 'index_count': indices['count'] if indices else None, 'render_mode': primitive.get('mode', 4), 'triangles': count//3 if primitive.get('mode', 4) == 4 else None, 'position_min': positions.get('min'), 'position_max': positions.get('max'), 'material': primitive.get('material')})
external = [x.get('uri') for x in document.get('images', []) + document.get('buffers', []) if x.get('uri') and not x['uri'].startswith('data:')]
inspection = {'status': 'original_generated_draft_awaiting_interactive_user_approval', 'inspected_at_utc': datetime.now(timezone.utc).isoformat(), 'request_id': '01a108be-bdb0-7293-b6ce-001746127d4f', 'endpoint_id': 'meshy/v7.1/multi-image-to-3d', 'file_bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest(), 'glb_version': version, 'nodes': document.get('nodes', []), 'mesh_count': len(document.get('meshes', [])), 'material_count': len(document.get('materials', [])), 'image_count': len(document.get('images', [])), 'animation_count': len(document.get('animations', [])), 'skin_count': len(document.get('skins', [])), 'extensions_used': document.get('extensionsUsed', []), 'extensions_required': document.get('extensionsRequired', []), 'external_dependencies': external, 'primitives': primitives, 'materials': document.get('materials', []), 'viewer_yaw_radians': 0, 'viewer_transforms': 'Parent-only presentation scale/centering/yaw; original GLB bytes unchanged', 'structural_note': f"The output contains {len(document.get('meshes', []))} mesh object(s), {len(document.get('materials', []))} material(s), and no approved mechanical rig. Part separability and joint construction remain unverified; review the original draft before cleanup.", 'geometry_cleanup_performed': False, 'rigging_performed': False, 'brand_overlay_applied': False}
(OUT / 'inspection.json').write_text(json.dumps(inspection, indent=2)+'\n')
(OUT / 'gltf-document.json').write_text(json.dumps(document, indent=2)+'\n')
(OUT / 'manifest.json').write_text(json.dumps({'request_id': inspection['request_id'], 'original_result': '../model-draft-result.json', 'downloaded_originals': downloads, 'all_output_urls': result, 'geometry_edits': 0, 'rigging': False}, indent=2)+'\n')
print(json.dumps({k: inspection[k] for k in ['sha256','file_bytes','mesh_count','material_count','image_count','animation_count','skin_count','extensions_required','external_dependencies']}))
