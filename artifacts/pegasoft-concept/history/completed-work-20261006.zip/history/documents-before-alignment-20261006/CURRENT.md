# Pegasoft Concept checkpoint

- **Accepted and locked:** [physical cab, solid wheels and connected lift/camera/settling sequence](generation/lift-family/reference-motion-approval.json). Approval includes clockwise forward/counterclockwise reverse scroll and diagnostic load contact. Preserve the exact [reviewed inputs](evidence/lift-wheel-volume-input/) and original model/rig/color locks.
- **Checks:** 192 wheel-part meshes closed; 24,480 depth/face probes, 601 reversible poses, fixed body, cab scope and pickup contact pass. Both surfaces, normal playback and genuine forward/reverse scroll inspected. [Packet](evidence/lift-motion-review.json).
- **Next gate:** persistent silver 40-foot container. Agree its minimum required views and model method; then generate the static master with Image 2.5 under the locked prompt and global color contract for carbon/porcelain approval. No overhead, underside or unused variants.
- **Deferred:** production-container attachment, trailer/deck handoff and final section framing require their assets and review. Do not treat diagnostic proxy approval as container acceptance. Follow [PROPOSAL.md](PROPOSAL.md).
